 <!-- mysqli_query($conexion,"Update Asiento set estado='ocupado'
                                 where num_asiento='$asiento'");
    */-->
<?php 
session_start();

setcookie('intentos',0,time()-1,'/');
setcookie('palabra',0,time()-1,'/');

setcookie('desordenada',0,time()-1,'/');


  if($conexion=mysqli_connect("localhost","root",""))
    {
        mysqli_query($conexion,"CREATE DATABASE IF NOT EXISTS QueMareoSudoku");
        
        mysqli_select_db($conexion,"QueMareoSudoku");


        
        mysqli_query($conexion,"CREATE TABLE Palabras(id_palabra int(2)                     PRIMARY KEY auto_increment,
                                tipo varchar(15) not null,
                                bien VARCHAR(20),
                                mal VARCHAR(20))");

        mysqli_query($conexion,"CREATE TABLE Usuarios(id_usuario int(2)  
                                auto_increment PRIMARY KEY,
                                nombre VARCHAR(20),
                                clave VARCHAR(20))");
        mysqli_query($conexion,"CREATE TABLE Partidas(id int(2)  
                                ,idUsu int(2),
                                intentos int(2),
                                ganapierde VARCHAR(20),
                                fechahora timestamp,
                                constraint PKPartidas PRIMARY KEY(id,idUsu,fechahora),
                                 constraint FKPalabras FOREIGN KEY(id)
                                 REFERENCES Palabras(id_palabra) ON UPDATE CASCADE ON DELETE CASCADE,
                                 constraint FKUsuarios FOREIGN KEY(idUsu)
                                 REFERENCES Usuarios(id_usuario) ON UPDATE CASCADE ON DELETE CASCADE)
                                ");
      $consulta=mysqli_query($conexion,"SELECT * FROM Palabras");

      $num=mysqli_num_rows($consulta);



        
                                
                             
                                                    

      if($num==0)
      {  
       mysqli_query($conexion,"INSERT into Palabras (tipo,bien,mal) values
        ('palabra','casa','asac')"); 
       mysqli_query($conexion,"INSERT into Palabras (tipo,bien,mal) values ('palabra','cantautor','acnurtort')"); 
        mysqli_query($conexion,"INSERT into Palabras (tipo,bien,mal) values
        ('palabra','peso','ospe')"); 
       mysqli_query($conexion,"INSERT into Palabras (tipo,bien,mal) values ('palabra','silla','llais')"); 
      } 
     if(isset($_SESSION['usuario']))
     { 
     $usu=$_SESSION['usuario'];
     $clave=$_SESSION['clave'];
     }  
 ?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>SB Admin - Start Bootstrap Template</title>
  <!-- Bootstrap core CSS-->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="css/miEstilo.css">
  <link rel="stylesheet" type="text/css" href="style.css">
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <!-- Navigation-->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <a class="navbar-brand" href="index.php">Inicio</a>
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
         <?php if(!isset($_SESSION['usuario']))
         { ?>
          <a class="nav-link" href="formularios/loginUsuario.php">
            <i class="fa fa-fw fa-dashboard"></i>
            <span class="nav-link-text">Inicio sesion(público)</span>
          </a>
          <?php }
          if(isset($_SESSION['usuario']))
          { ?>

            <a class="nav-link" href="formularios/cerrarSession.php">
            <i class="fa fa-fw fa-dashboard"></i>
            <span class="nav-link-text">Cerrar session</span>
            </a>
          <?php  } ?>
        </li>
       
        
       
    
        
      </ul>
    </div>
  </nav>

  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb bg-warning">
        <li class="breadcrumb-item">
          <a href="#"></a>
        </li>
        <li class="breadcrumb-item active text-dark font-weight-bold">
        <?php 
        if(isset($_SESSION['usuario']))
        { ?>
        Qué Mareo y sudoku <?php echo ", Hola $usu";?></li>
        <?php 
        }
        else
        { ?>
        Qué Mareo y sudoku
        <?php } ?> </li>
      </ol>
      <!-- Icon Cards-->
      <div class="row">
          <div class="col-lg-12">
                    <h1 class="page-header" style="margin-left:27px">Público</h1>
                </div>
        <?php if(!isset($_SESSION['usuario']))
              {
              ?>

        <div class="col-xl-6 col-sm-6 mb-3">
          <div class="card text-white bg-primary o-hidden h-100">
            <div class="card-body">
              <div class="card-body-icon">
                <i class="fa fa-pencil-square"></i>
              </div>
           <a class="nav-link" href="formularios/registroUsuario.php">
            <div class="mr-5 text-white">Alta</div>
            </div>
            <a class="card-footer text-white clearfix small z-1" href="#">
              <span class="float-left"></span>
              <span class="float-right">
                <i class="fa fa-angle-right"></i>
              </span>
            </a>
          </div>
        </div>
        <div class="col-xl-6 col-sm-6 mb-3">
          <div class="card text-white bg-warning o-hidden h-100">
            <div class="card-body">
              <div class="card-body-icon">
                <i class="fa fa-fw fa-play-circle"></i>
              </div>
              <a class="nav-link" href="formularios/loginUsuario.php">
              <div class="mr-5">Iniciar sesion</div>
            </div>
            <a class="card-footer text-white clearfix small z-1" href="#">
              <span class="float-left"></span>
              <span class="float-right">
                <i class="fa fa-angle-right"></i>
              </span>
            </a>
          </div>
        </div>
        <div class="col-xl-12 col-sm-12 mb-3">
          <div class="card text-white bg-info o-hidden h-100">
            <div class="card-body">
              <div class="card-body-icon">
                 <i class="fa fa-fw fa-file-text"></i>
              </div>
              <a class="nav-link" href="formularios/consultar.php">
              <div class="mr-5">Consultar</div>
            </div>
            <a class="card-footer text-white clearfix small z-1" href="#">
              <span class="float-left"></span>
              <span class="float-right">
                <i class="fa fa-angle-right"></i>
              </span>
            </a>
          </div>
        </div>
        <?php }
        else {
           
          ?>
           <div class="col-xl-6 col-sm-6 mb-3">
          <div class="card text-white bg-primary o-hidden h-100">
            <div class="card-body">
              <div class="card-body-icon">
                <i class="fa fa-play"></i>
              </div>
           <a class="nav-link" href="formularios/jugar.php">
            <div class="mr-5 text-white">Jugar a que mareo</div>
            </div>
            <a class="card-footer text-white clearfix small z-1" href="#">
              <span class="float-left"></span>
              <span class="float-right">
                <i class="fa fa-angle-right"></i>
              </span>
            </a>
          </div>
        </div>

        <div class="col-xl-6 col-sm-6 mb-3">
          <div class="card text-white bg-primary o-hidden h-100">
            <div class="card-body">
              <div class="card-body-icon">
                <i class="fa fa-fw fa-gamepad"></i>
              </div>
           <a class="nav-link" href="codigos/principal.php?sudoku">
            <div class="mr-5 text-white">Jugar al sudoku</div>
            </div>
            <a class="card-footer text-white clearfix small z-1" href="#">
              <span class="float-left"></span>
              <span class="float-right">
                <i class="fa "></i>
              </span>
            </a>
          </div>
        </div>

        <div class="col-xl-6 col-sm-6 mb-3">
          <div class="card text-white bg-danger o-hidden h-100">
            <div class="card-body">
              <div class="card-body-icon">
                <i class="fa fa-fw fa-eraser"></i>
              </div>
           <a class="nav-link" href="formularios/modificar.php">
            <div class="mr-5 text-white">Modificar Contraseña</div>
            </div>
            <a class="card-footer text-white clearfix small z-1" href="#">
              <span class="float-left"></span>
              <span class="float-right">
                <i class="fa fa-angle-right"></i>
              </span>
            </a>
          </div>
        </div>

        <div class="col-xl-6 col-sm-6 mb-3">
          <div class="card text-white bg-danger o-hidden h-100">
            <div class="card-body">
              <div class="card-body-icon">
                <i class="fa fa-fw fa-eraser"></i>
              </div>
           <a class="nav-link" href="formularios/borrarUsuario.php">
            <div class="mr-5 text-white">Borrar Usuario</div>
            </div>
            <a class="card-footer text-white clearfix small z-1" href="#">
              <span class="float-left"></span>
              <span class="float-right">
                <i class="fa fa-angle-right"></i>
              </span>
            </a>
          </div>
        </div>
        <div class="col-xl-12 col-sm-12 mb-3">
          <div class="card text-white bg-info o-hidden h-100">
            <div class="card-body">
              <div class="card-body-icon">
                <i class="fa fa-fw fa-question"></i>
              </div>
              <a class="nav-link" href="formularios/consultar.php">
              <div class="mr-5">Consultar</div>
            </div>
            <a class="card-footer text-white clearfix small z-1" href="#">
              <span class="float-left"></span>
              <span class="float-right">
                <i class="fa fa-angle-right"></i>
              </span>
            </a>
          </div>
        </div>
      
      
        
        
        <?php } ?>
       

       
      <!-- Area Chart Example-->
      
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <footer class="sticky-footer">
      <div class="container">
        <div class="text-center">
          <small>Caress your soul</small>
        </div>
      </div>
    </footer>
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fa fa-angle-up"></i>
    </a>
    <!-- Logout Modal-->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="login.html">Logout</a>
          </div>
        </div>
      </div>
    </div>
    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Page level plugin JavaScript-->
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>
    <!-- Custom scripts for this page-->
    <script src="js/sb-admin-datatables.min.js"></script>
    <script src="js/sb-admin-charts.min.js"></script>
  </div>
</body>

</html>
<?php } ?>
