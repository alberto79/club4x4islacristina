<?php 
session_start();
include("../codigos/funciones.php");
Encabezado();
echo "<h5>Enhorabuena, has hecho el sudoku correctamente</h5>";
$intentos=$_COOKIE['intentos'];



 ?>
 <div class="w-100 mb-2"></div>
 <!--<div class="row justify-content-center">
        <a class="btn bg-success text-white font-weight-bold align-content-center text-center pl-4 pr-4" href="../index.php">Volver
        </a>
        </div>-->
 <?php 
 //Pie();
 $palabra='';
 meterPartida($intentos,'gana','sudoku',$palabra);


  ?>        