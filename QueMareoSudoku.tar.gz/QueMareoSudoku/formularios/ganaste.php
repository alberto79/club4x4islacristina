<?php 
 
session_start();

 include("../codigos/funciones.php");
  
       Encabezado();
       echo "Enhorabuena, acertaste";   
        ?>
            <div class="w-100 mb-2"></div>
            <div class="row justify-content-center">
            <a class="btn bg-success text-white font-weight-bold     align-content-center text-center pl-4 pr-4" href="../index.php">Volver
           </a>
           </div>
        <?php 
       
      if(isset($_COOKIE['palabra']))
      {
         $buscada=$_COOKIE['palabra'];
         $intentos=$_COOKIE['intentos'];
        
      }    
       
      Pie();
      meterPartidaPerdida($intentos,'gana','palabra',$buscada);
     
                                                   

  ?>