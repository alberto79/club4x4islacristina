<?php 
session_start();
 ?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>SB Admin - Start Bootstrap Template</title>
  <!-- Bootstrap core CSS-->
  <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="../vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="../css/sb-admin.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="css/miEstilo.css">
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <!-- Navigation-->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <a class="navbar-brand" href="index.php">Inicio</a>
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
   <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
         <?php if(!isset($_SESSION['usuario']))
         { ?>
          <a class="nav-link" href="formularios/loginUsuario.php">
            <i class="fa fa-fw fa-dashboard"></i>
            <span class="nav-link-text">Inicio sesion(público)</span>
          </a>
          <?php }
          if(isset($_SESSION['usuario']))
          { ?>

            <a class="nav-link" href="formularios/cerrarSession.php">
            <i class="fa fa-fw fa-dashboard"></i>
            <span class="nav-link-text">Cerrar session</span>
            </a>
          <?php  } ?>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Charts">
         <?php if(!isset($_SESSION['administrador']))
               { ?>
              <a class="nav-link" href="formularios/registroAdmin.php">
              <i class="fa fa-fw fa-area-chart"></i>
              <span class="nav-link-text">Inicio sesion(administrador)</span>
             </a>
             <?php }
             if(isset($_SESSION['administrador']))
               { ?>
              <a class="nav-link" href="formularios/cerrarSession.php">
              <i class="fa fa-fw fa-area-chart"></i>
              <span class="nav-link-text">Cerrar session(administrador)</span>
             </a>
             <?php } ?>
        </li>
        
          </ul>
        </li>
    
        
      </ul>
      <div class="container-fluid bg-white pb-5">
       <ol class="breadcrumb bg-warning mt-2">
        <li class="breadcrumb-item">
          <a href="#"></a>
        </li>
        <li class="breadcrumb-item active text-dark font-weight-bold">Que Mareo</li>
      </ol>
      <div class="row justify-content-center">
      <div class="mb-2""><h3>Alta de nuevo usuario</h3></div>
      </div>
       

        <form action="../codigos/principal.php" method="post">
       
           

          <div class="form-group">
         
          <label class="font-weight-bold">Nombre:</label>
          <input class="form-control" type="text" name="altaNombre" placeholder="Nombre del usuario">
          </div>

          <div class="form-group">
         
          <label class="font-weight-bold">Contraseña:</label>
          <input class="form-control" type="text" name="altaClave" placeholder="Contraseña">
          </div>
         

         
          
          <div class="form-group">
         
         
          <div class="row justify-content-around">
          <input type="submit" class="btn bg-success text-white" name="#" value="Alta usuario">
          <a class="btn bg-success font-weight-bold text-white" href="../index.php">Volver</a>
          </div>
       

          </form>
        
      
      </div>

    <!-- Bootstrap core JavaScript-->
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Page level plugin JavaScript-->
    <script src="../vendor/chart.js/Chart.min.js"></script>
    <script src="../vendor/datatables/jquery.dataTables.js"></script>
    <script src="../vendor/datatables/dataTables.bootstrap4.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="../js/sb-admin.min.js"></script>
    <!-- Custom scripts for this page-->
    <script src="../js/sb-admin-datatables.min.js"></script>
    <script src="../js/sb-admin-charts.min.js"></script>
  </div>
</body>

</html>
