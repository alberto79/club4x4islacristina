<?php 
include("funciones2.php");
function altaFichero ($varPalabra)
{
          $f1=fopen("ficheroDEPalabra.txt","a+");
            fwrite($f1,$varPalabra."\r\n");
          
          fclose($f1);
}

function iniciar_sesion($varnombre,$clave)
{
        if($conexion=mysqli_connect("localhost","root",""))
        {       
            mysqli_select_db($conexion,"QueMareoSudoku");

            $consulta=mysqli_query($conexion,"SELECT * FROM Usuarios WHERE nombre='$varnombre' and clave like '$clave'");

            $num=mysqli_num_rows($consulta);
            $u=mysqli_fetch_row($consulta);
            $usuario=$u;

            if($num>0)
                {
                    session_destroy();
                    session_start();
                    $_SESSION['usuario'] = $varnombre;
                    $_SESSION['clave'] = $clave;
                    header("Location:../index.php");
                }
                else
                {
                    echo "<table align='center' style='margin-top:15px;'>";
                    echo "<tr>";
                    echo "<td style='background-color: blue;color:white;font-weight: bold;'>¡No se ha encontrado a este usuario en el sistema<td></tr>";
                    echo "</table>";

                    echo "<table align='center' style='margin-top:15px;'>";
                    echo "<tr>";
                    echo "<td><a href='../index.php' style='text-decoration: none;'>Volver</a><td></tr>";
                    echo "</table>";


                }
        }
        else
        {
            echo "<table align='center' style='margin-top:15px;'>";
                    echo "<tr>";
                    echo "<td style='background-color: blue;color:white;font-weight: bold;'>¡No se ha podido establecer la conexión<td></tr>";
                 
                    echo "</table>";
                    echo "<table align='center' style='margin-top:15px;'>";
                    echo "<tr>";
                    echo "<td><a href='../index.php' style='text-decoration: none;'>Volver</a><td></tr>";
                    echo "</table>";
        }
}



function usuario_alta($nom,$clave)
{
        if($conexion=mysqli_connect("localhost","root",""))
        {       
            mysqli_select_db($conexion,"QueMareoSudoku");
            $consulta=mysqli_query($conexion,"SELECT * FROM Usuarios WHERE nombre='$nom' and clave like '$clave'");
            
            $num=mysqli_num_rows($consulta);
          
          if($num>0)
          {
                echo "<table align='center' style='margin-top:15px;'>";
                echo "<tr>";
                echo "<td style='background-color: blue;color:white;font-weight: bold;'>Ya hay un usuario registrado con ese nombre y contraseña<td></tr>";
                 
                echo "</table>";
                echo "<table align='center' style='margin-top:15px;'>";
                echo "<tr>";
                echo "<td><a href='../index.php' style='text-decoration: none;'>Volver</a><td></tr>";
                echo "</table>";
          }
          else
          {
            if(mysqli_query($conexion,"INSERT INTO Usuarios (nombre,clave) VALUE ('$nom','$clave')"))
            {
               echo "<table align='center' style='margin-top:15px;'>";
                    echo "<tr>";
                    echo "<td style='background-color: blue;color:white;font-weight: bold;'>¡Se ha registrado el nuevo usuario!<td></tr>";
                 
                    echo "</table>";
                    echo "<table align='center' style='margin-top:15px;'>";
                    echo "<tr>";
                    echo "<td><a href='../index.php' style='text-decoration: none;'>Volver</a><td></tr>";
                    echo "</table>";
            }
          } 



        }
        else
        {
                    echo "<table align='center' style='margin-top:15px;'>";
                    echo "<tr>";
                    echo "<td style='background-color: blue;color:white;font-weight: bold;'>¡No se pudo conectar a la Base de Datos!<td></tr>";
                 
                    echo "</table>";
                    echo "<table align='center' style='margin-top:15px;'>";
                    echo "<tr>";
                    echo "<td><a href='../index.php' style='text-decoration: none;'>Volver</a><td></tr>";
                    echo "</table>";
        }
}
function baja_usuario($varnombre,$varclave)
{
   
        if($conexion=mysqli_connect("localhost","root",""))
        {       
            mysqli_select_db($conexion,"QueMareoSudoku");
            $consulta=mysqli_query($conexion,"SELECT * FROM Usuarios WHERE nombre='$varnombre' and clave like '$varclave'");

            $num=mysqli_num_rows($consulta);
            if($num>0)
            {
                mysqli_query($conexion,"DELETE FROM Usuarios WHERE nombre='$varnombre' and clave like'$varclave'");
                
                    echo "<table align='center'>";
                    echo "<tr>";
                    echo "<td style='background-color: blue;color:white;font-weight: bold;'>¡Se ha ELIMINADO el usuario de la Base de Datos!<td></tr>";
                    session_destroy();
                    echo "</table>";
                    echo "</table>";
                    echo "<table align='center' style='margin-top:15px;'>";
                    echo "<tr>";
                    echo "<td><a href='../index.php' style='text-decoration: none;'>Volver</a><td></tr>";
                    echo "</table>";

               
            }    
           else
           {
                    echo "<table align='center' style='margin-top:15px;'>";
                    echo "<tr>";
                    echo "<td style='background-color: blue;color:white;font-weight: bold;'>¡No hay ningun usuario con esos datos!<td></tr>";
                 
                    echo "</table>";
                    echo "</table>";
                    echo "<table align='center' style='margin-top:15px;'>";
                    echo "<tr>";
                    echo "<td><a href='../index.php' style='text-decoration: none;'>Volver</a><td></tr>";
                    echo "</table>";
           } 

               
            
        }
        else
        {
        echo "<table align='center' style='margin-top:15px;'>";
                    echo "<tr>";
                    echo "<td style='background-color: blue;color:white;font-weight: bold;'>¡No se ha podido conectar a la base de datos!<td></tr>";
                 
                    echo "</table>";
                    echo "</table>";
                    echo "<table align='center' style='margin-top:15px;'>";
                    echo "<tr>";
                    echo "<td><a href='../index.php' style='text-decoration: none;'>Volver</a><td></tr>";
                    echo "</table>";
        }

}

function modifica_usuario($varnombre,$varclavevieja,$varclaveNueva)
{
   
        if($conexion=mysqli_connect("localhost","root",""))
        {       
            mysqli_select_db($conexion,"QueMareoSudoku");
            $consulta=mysqli_query($conexion,"SELECT * FROM Usuarios WHERE nombre='$varnombre' and clave like '$varclavevieja'");

            $num=mysqli_num_rows($consulta);
            if($num>0)
            {
                mysqli_query($conexion,"UPDATE Usuarios SET clave='$varclaveNueva'
                    WHERE NOMBRE LIKE '$varnombre' AND CLAVE LIKE '$varclavevieja'");
                
                    echo "<table align='center'>";
                    echo "<tr>";
                    echo "<td style='background-color: blue;color:white;font-weight: bold;'>¡Se ha MODIFICADO la contraseña  del usuario !<td></tr>";
               
                    echo "</table>";
                    echo "<table align='center' style='margin-top:15px;'>";
                    echo "<tr>";
                    echo "<td><a href='../index.php' style='text-decoration: none;'>Volver</a><td></tr>";
                    echo "</table>";

               
            }    
           else
           {
                    echo "<table align='center' style='margin-top:15px;'>";
                    echo "<tr>";
                    echo "<td style='background-color: blue;color:white;font-weight: bold;'>¡No hay ningun usuario con esos datos!<td></tr>";
                 
                    echo "</table>";
                    echo "</table>";
                    echo "<table align='center' style='margin-top:15px;'>";
                    echo "<tr>";
                    echo "<td><a href='../index.php' style='text-decoration: none;'>Volver</a><td></tr>";
                    echo "</table>";
           } 

               
            
        }
        else
        {
        echo "<table align='center' style='margin-top:15px;'>";
                    echo "<tr>";
                    echo "<td style='background-color: blue;color:white;font-weight: bold;'>¡No se ha podido conectar a la base de datos!<td></tr>";
                 
                    echo "</table>";
                    echo "</table>";
                    echo "<table align='center' style='margin-top:15px;'>";
                    echo "<tr>";
                    echo "<td><a href='../index.php' style='text-decoration: none;'>Volver</a><td></tr>";
                    echo "</table>";
        }

}
if(isset($_GET['sudoku']))
{
  setcookie('intentos',0,time()-1,'/');  
  $n1=''; 
  $n3=''; 
  $n4=''; 
  $n5=''; 
  $n6='';
  generarSudoku($n1,$n3,$n4,$n5,$n6);  
}   
  

function generarSudoku()
{       

      setcookie('num1',0,time()-1,'/');
      setcookie('num2',0,time()-1,'/');
      setcookie('num3',0,time()-1,'/');
      setcookie('num4',0,time()-1,'/');
      setcookie('num5',0,time()-1,'/');
      setcookie('num5',0,time()-1,'/');

       do
       {
        
        $num1=rand(1,6);
        $num2=rand(1,6);
        $num3=rand(1,6);

        $num6=rand(1,6);
        $num4=rand(1,6);
        $num5=rand(1,6);
        $col1[0]=$num1;
        $col1[1]=$num2;
        $col1[2]=$num3;
        $col2[0]=$num4;
        $col2[1]=$num5;
        $col2[2]=$num6;
       }
       while($num1==$num2||$num1==$num3||$num2==$num3||$col1[0]==$col2[0]
        ||$col1[1]==$col2[1]||$col1[2]==$col2[2]||$num4==$num5||
        $num4==$num6||$num5==$num6||$num1==$num4||$num1==$num5||$num1==$num6||$num2==$num4||$num2==$num6||$num3==$num5||$num3==$num6||$num3==$num4
       );
      setcookie('num1',$col1[0],time()+3600,'/');
      setcookie('num2',$col1[1],time()+3600,'/');
      setcookie('num3',$col1[2],time()+3600,'/');
      setcookie('num4',$col2[0],time()+3600,'/');
      setcookie('num5',$col2[1],time()+3600,'/');
      setcookie('num6',$col2[2],time()+3600,'/');
       ?>
     
       <form action="principal.php" method="get">
      <?php 
       Encabezado();
      ?>
       <a class="btn bg-white text-dark border border-dark mr-5"
       href="funciones.php?sudoku">Inicio</a>
       <input class="btn bg-white text-dark border border-dark mr-5"
       type="submit" value="Comprobar" name="Comprobar"></a>
       <a class="btn bg-white text-dark border border-dark mr-5"
       href="funciones.php?solucion">Solucion</a>
       </div>
       <div class="w-100 mb-3"></div>
      <?php
       echo "<table align='center'>";
       echo "<tr>";
          for($i=0;$i<3;$i++)
          {
             if($i==1)
             {    
             echo "<td class='letra' align='center'  style='width:100px;height:70px;background-color:yellow;'> ";
             echo $col1[$i].'</td>';
             }
             else
             {
               echo "<td align='center' class='letra' style='width:100px;height:70px;background-color:yellow;'> ";
               if($i==0)
               {
                ?>
                <input type="text" name="num1">
               
        <?php  }
               if($i==2)
               {
                ?>
                <input type="text" name="num3">
               
        <?php  } 
             echo '</td>';
             } 
            
           
          }
        $fila1=$num1+$num2+$num3;
    
      if($fila1<10)
      $fila1='0'.$fila1;  
      echo "<td class='letra2 icon-arrow-right2'>$fila1</td>";   
      echo "</tr>";  
      echo "<tr>"; 
          for($i=0;$i<3;$i++)
          {
            
             echo "<td align='center' class='letra' style='width:100px;height:70px;background-color:yellow;'> ";
              if($i==1)
               {
               
                ?>
                <input type="text" name="num5">
               
        <?php  }
            
               
               if($i==0)
               {

                ?>
                <input type="text" name="num4">
               
        <?php  }
               if($i==2)
               {
                ?>
                <input type="text" name="num6">
               
        <?php  } 
             echo '</td>';
            
                
           
               
            
          }
        $fila2=$num4+$num5+$num6;
        $col1=$num1+$num4;
        $col2=$num2+$num5;
        $col3=$num3+$num6;
        if($fila2<10)
        $fila2='0'.$fila2; 
        echo "<td class='letra2 icon-arrow-right2'>$fila2</td>"; 
    
     
        echo "</tr>";  
        echo "<tr>";
 
       echo "<td class='icon-arrow-down2 letra2'>$col1</td>";
       echo "<td class='icon-arrow-down2 letra2'>$col2</td>";
       echo "<td class='icon-arrow-down2 letra2'>$col3</td></tr>"; 

        ?>
      </table> 
      </form>
     
    <table align="center" style="margin-top: 7px;">
      <tr>
      
      <td align="center">
      <a class="btn bg-success text-white font-weight-bold align-content-center text-center pl-4 pr-4" align="center" href="../index.php">Volver
        </a></td></tr>
      </table>
    
     <?php  
     exit();
     Pie();   
        
        

}
function comprobarSudoku($v1,$v3,$v4,$v5,$v6)
{   
$correcto=0;    
     // if($correcto==1)
     // header('location:correcto.php');
      
      $su1=$_COOKIE['num1'];
      $su2=$_COOKIE['num2'];
      $su3=$_COOKIE['num3'];
      $su4=$_COOKIE['num4'];
      $su5=$_COOKIE['num5'];
      $su6=$_COOKIE['num6'];
     

          if($v1==$su1&&$v3==$su3&&$v4==$su4&&$v5==$su5&&$v6==$su6)
           { 
          
           // header('location:../formularios/correcto.php');
            $correcto=1;
           

           }
           else
           {
           ?>

           <div class="w-100"></div>
           <div class="row justify-content-center">
           <h3 class="bg-success text-white">Ha habido algún error, pruebe otra vez</h3>
           </div>
           <?php 
           } 


       ?>
     
      <form action="principal.php" method="get">
      <div class="row justify-content-start">
      <?php 
       Encabezado();
       $intentos=0;
        if(isset($_COOKIE['intentos']))
       {
        $intentos=$_COOKIE['intentos'];
        $intentos++;
      
        setcookie('intentos',$intentos,time()+3600,'/');
       } 
       else
       {
       
        setcookie('intentos',2,time()+3600,'/');
        $intentos=2;
       } 
     
    if($intentos>=3)
    {
       meterPartidaPerdida($intentos,'pierde','sudoku','');

                  
       ?>
   
       
        
       <a class="btn bg-white text-dark border border-dark mr-5"
       href="funciones.php?sudoku">Inicio</a>
       <a class="btn bg-danger text-white border border-dark mr-5"
       >Comprobar</a>
       <a class="btn bg-white text-dark border border-dark mr-5"
       href="funciones.php?solucion">Solucion</a>
       </div>
       <div class="w-100 mb-3"></div>

       
       <?php 
    }
      
       else
       { 
          
       ?> 
      <!-- <div class='text-danger mr-5'>LLeva <?php echo $intentos; ?> intentos</div>-->
   
        

  
       <a class="btn bg-white text-dark border border-dark mr-5"
       href="funciones.php?sudoku">Inicio</a>
       <input class="btn bg-white text-dark border border-dark mr-5"
       type="submit" value="Comprobar" name="Comprobar"></a>
       <a class="btn bg-white text-dark border border-dark mr-5"
       href="funciones.php?solucion">Solucion</a>
       </div>
       <div class="w-100 mb-3"></div>

       <?php

       }?>
       <div class="w-100 mb-3"></div>
     <?php  
     //Aqui comienza la tabla de numeros del sudoku
       echo "<table border='0' align='center'>";
       echo "<tr>";
          for($i=0;$i<3;$i++)
          {
             if($i==1)
             {    
             echo "<td class='letra' align='center'  style='width:100px;height:70px;background-color:yellow;'>";
             echo $su2.'</td>';
             }
             if($i==0)
             {
             ?>
                <td align="center" style="width:100px;height:70px;background-color:yellow;" class="letra">
                <input type="text" name="num1"></td>
               
       <?php }
             if($i==2)
             {
             ?>
                <td align="center" style="width:100px;height:70px;background-color:yellow;" class="letra">
                <input type="text" name="num3"></td>
        <?php    
             }
           }  
                
           
          
      $fila1= $su1+$su2+$su3;
      if($fila1<10)
      $fila1='0'.$fila1;  
     //sumo los tres numeros de la primera fila
      echo "<td class='letra2 icon-arrow-right2'>$fila1</td>";     
      echo "</tr>"; 
     
      echo "<tr>"; 
          for($i=0;$i<3;$i++)
          {
            
             echo "<td align='center' class='letra'  style='width:100px;height:70px;background-color:yellow;'>";
              if($i==1)
               {
               
                ?>
                <input type="text" name="num5">
               
        <?php  }
            
               
               if($i==0)
               {

                ?>
                <input type="text" name="num4">
               
        <?php  }
               if($i==2)
               {
                ?>
                <input type="text" name="num6">
               
        <?php  } 
             echo '</td>';
            
                
           
               
            
          }
        $fila2=$su4+$su5+$su6;
        if($fila2<10)
        $fila2='0'.$fila2;    
        $col1=$su1+$su4;
        $col2=$su2+$su5;
        $col3=$su3+$su6;

        echo "<td class='letra2 icon-arrow-right2'>$fila2</td>";    
        echo "</tr>"; 
           
        
       
       echo "<tr>";
 
       echo "<td class='icon-arrow-down2 letra2'>$col1</td>";
       echo "<td class='icon-arrow-down2 letra2'>$col2</td>";
       echo "<td class='icon-arrow-down2 letra2'>$col3</td></tr>";
       echo "</table>";
      // muestro los numeros de la cookie para ver la solucion;
         echo "guardados $su1,$su2,$su3,$su4,$su5,$su6";?>
      
      <h3 class='text-danger mr-5'>LLeva <?php echo $intentos-1; ?> intentos</h3>
      <?php  
       echo "</form>";
       if($intentos==3)
       {
       ?>
        <div class="w-100"></div>
        <div class="row justify-content-center">
        <h3 class="bg-success text-white">Ha agotado sus intentos</h3>
        </div>
        <?php 
        exit();    
       
       }
      if($correcto==0)
       { 
        ?>

           <div class="w-100"></div>
           <div class="row justify-content-center">
           <h3 class="bg-success text-white">Ha habido algún error, pruebe otra vez</h3>
           </div>
           <?php 
       }
          
           
           ?>
    <!--    <div class="w-100 my-1"></div>
        <div class="w-100 my-1"></div>
        <div class="row justify-content-center">
        <a class="btn bg-success text-white font-weight-bold align-content-center text-center pl-4 pr-4" href="../index.php">Volver
        </a>
        </div>
        </div>-->

       <?php  
       Pie();

      
      
        
        

}

if(isset($_GET['solucion']))
solucion();  

function solucion()
{       

    if(isset($_COOKIE['num1']))
    {
      $su1=$_COOKIE['num1'];
      $su2=$_COOKIE['num2'];
      $su3=$_COOKIE['num3'];
      $su4=$_COOKIE['num4'];
      $su5=$_COOKIE['num5'];
      $su6=$_COOKIE['num6'];
    }  
       ?>
     
    
       <?php 
       Encabezado();
       ?> 
       <div class="row justify-content-center">
      
      
      
      
       
    

      
       <a class="btn bg-white text-dark border border-dark mr-1"
       href="funciones.php?sudoku">Inicio</a>
       <input class="btn bg-white text-dark border border-dark mr-5"
       type="submit" value="Comprobar" name="Comprobar"/>
       <a class="btn bg-white text-dark border border-dark"
       href="#">Solucion</a>
     

       <div class="w-100 mb-3"></div>

       <?php  
       echo "<table border='1' align='center'>";
       echo "<tr>";
          for($i=0;$i<3;$i++)
          {
             if($i==0)
             {    
             echo "<td class='letra' align='center'  style='width:100px;height:70px;background-color:yellow;'> ";
             echo $su1.'</td>';
             }
             if($i==1)
             {    
             echo "<td class='letra' align='center'  style='width:100px;height:70px;background-color:yellow;'> ";
             echo $su2.'</td>';
             }
             if($i==2)
             {    
             echo "<td class='letra' align='center'  style='width:100px;height:70px;background-color:yellow;'> ";
             echo $su3.'</td>';
             }
           
          }
      echo "</tr>";  
      echo "<tr>"; 
          for($i=0;$i<3;$i++)
          {
             if($i==0)
             {    
             echo "<td class='letra' align='center'  style='width:100px;height:70px;background-color:yellow;'> ";
             echo $su4.'</td>';
             }
             if($i==1)
             {    
             echo "<td class='letra' align='center'  style='width:100px;height:70px;background-color:yellow;'> ";
             echo $su5.'</td>';
             }
              if($i==2)
             {    
             echo "<td class='letra' align='center'  style='width:100px;height:70px;background-color:yellow;'> ";
             echo $su6.'</td>';
             }
           
          }
       echo "</tr>";   
        
       
       echo "</table> ";
      ?>
        <div class="w-100 my-1"></div>
        <div class="w-100 my-1"></div>
        <a class="btn bg-success text-white font-weight-bold align-content-center text-center pl-4 pr-4" href="../index.php">Volver
        </a>
       
        </div>

       <?php  
       Pie();


      
      
        
        

}


function meterPartida($varIntentos,$varGanaPierde,$tipo,$palabra)
{
   $usuario=$_SESSION['usuario'];
   $clave=$_SESSION['clave'];
     if($conexion=mysqli_connect("localhost","root",""))
     {       
            mysqli_select_db($conexion,"QueMareoSudoku");
            $consulta=mysqli_query($conexion,"Select id_usuario from 
            Usuarios where nombre like '$usuario' and clave like '$clave'" );
           $i=0;        
               while($registro = mysqli_fetch_assoc($consulta))
               {     
                   $id_usu[$i]=$registro['id_usuario'];
                   $i++; 
               } 
         if($tipo=='sudoku')
         $consulta=mysqli_query($conexion,"INSERT into Palabras(tipo) value ('$tipo')");
          if($palabra=='')
          {  
               $consulta=mysqli_query($conexion,"Select id_palabra from 
               Palabras where tipo like '$tipo' order by id_palabra desc limit 1" );
          }  
          else
          {
               $consulta=mysqli_query($conexion,"Select id_palabra from 
               Palabras where bien like '$palabra'" );       
          }   
               $i=0;        
               while($registro = mysqli_fetch_assoc($consulta))
               {     
                   $id_palabra[$i]=$registro['id_palabra'];
                   $i++; 
               } 

               

            $consulta=mysqli_query($conexion,"INSERT into Partidas(id,idUsu,intentos,ganapierde,fechahora)values('$id_palabra[0]','$id_usu[0]','$varIntentos','$varGanaPierde',now())");

          /*   Encabezado();
             echo "id_palabra $id_palabra[0],usuario $id_usu[0]";
             echo "Se introdujeron los datos en la base de datos";*/
             ?>
             <div class="w-100 mb-2"></div>
             <div class="row justify-content-center">
             <a class="btn bg-success text-white font-weight-bold align-content-center text-center pl-4 pr-4" href="../index.php">Volver
             </a>
            </div>
            <?php
             Pie();
    }
    else
    {
            Encabezado();
            echo "No se pudo conectar a la base de datos";
            ?>
            <div class="w-100 mb-2"></div>
            <div class="row justify-content-center">
             <a class="btn bg-success text-white font-weight-bold align-content-center text-center pl-4 pr-4" href="../index.php">Volver
        </a>
        </div>
        <?php 
        Pie();
    } 

  
}




function meterPartidaPerdida($varIntentos,$varGanaPierde,$tipo,$palabra)
{
   $usuario=$_SESSION['usuario'];
   $clave=$_SESSION['clave'];
     if($conexion=mysqli_connect("localhost","root",""))
     {       
            mysqli_select_db($conexion,"QueMareoSudoku");
            $consulta=mysqli_query($conexion,"Select id_usuario from 
            Usuarios where nombre like '$usuario' and clave like '$clave'" );
           $i=0;        
               while($registro = mysqli_fetch_assoc($consulta))
               {     
                   $id_usu[$i]=$registro['id_usuario'];
                   $i++; 
               } 
         if($tipo=='sudoku')
         $consulta=mysqli_query($conexion,"INSERT into Palabras(tipo) value ('$tipo')");
          if($palabra=='')
          {  
               $consulta=mysqli_query($conexion,"Select id_palabra from 
               Palabras where tipo like '$tipo' order by id_palabra desc limit 1" );
          }  
          else
          {
               $consulta=mysqli_query($conexion,"Select id_palabra from 
               Palabras where bien like '$palabra'" );       
          }   
               $i=0;        
               while($registro = mysqli_fetch_assoc($consulta))
               {     
                   $id_palabra[$i]=$registro['id_palabra'];
                   $i++; 
               } 

               

            $consulta=mysqli_query($conexion,"INSERT into Partidas(id,idUsu,intentos,ganapierde,fechahora)values('$id_palabra[0]','$id_usu[0]','$varIntentos','$varGanaPierde',now())");

          /*   Encabezado();
             echo "id_palabra $id_palabra[0],usuario $id_usu[0]";
             echo "Se introdujeron los datos en la base de datos";*/
             ?>
            <!-- <div class="w-100 mb-2"></div>
             <div class="row justify-content-center">
             <a class="btn bg-success text-white font-weight-bold align-content-center text-center pl-4 pr-4" href="../index.php">Volver
             </a>
            </div>-->
            <?php
           //  Pie();
    }
  /*  else
    {
            Encabezado();
            echo "No se pudo conectar a la base de datos";
            ?>
            <div class="w-100 mb-2"></div>
            <div class="row justify-content-center">
             <a class="btn bg-success text-white font-weight-bold align-content-center text-center pl-4 pr-4" href="../index.php">Volver
        </a>
        </div>
        <?php 
        Pie();
    } */

  
}



function todos()
{
     
     if($conexion=mysqli_connect("localhost","root",""))
     {       
            mysqli_select_db($conexion,"QueMareoSudoku");
            $consulta=mysqli_query($conexion,"Select id_usuario 'id_usuario',nombre 'nombre',ganapierde 'resultado',
            sum(intentos)'intentos',count(ganapierde)'cuenta_resu' from  
            Usuarios u join Partidas p on id_usuario=idUsu
            group by 1,2,3" );
           $i=0;        
               while($registro = mysqli_fetch_assoc($consulta))
               {     
                   $id_usu[$i]=$registro['id_usuario'];
                   $nombre[$i]=$registro['nombre'];
                   $resultado[$i]=$registro['resultado'];
                   $intentos[$i]=$registro['intentos'];
                   $cuenta_resu[$i]=$registro['cuenta_resu'];
                   $i++; 
               } 
          
           
                  
                
           Encabezado();
           ?>
           <table class="table-bordered table-striped">
           <tr>
           <th class="p-2">Id usuario</th><th>Nombre</th>
           <th>Resultado</th><th>Intentos</th><th>Cuenta resultados</th>
           </tr>
           <?php  
           for($i=0;$i<count($id_usu);$i++)
           {
             echo "<tr><td align='center'>$id_usu[$i]</td><td align='center'>$nombre[$i]</td><td align='center'>$resultado[$i]</td><td align='center'>$intentos[$i]</td><td align='center'>$cuenta_resu[$i]</td></tr>";
           } 
           echo "</tr>";
            ?>  
            </table>
             <div class="w-100 my-2"></div>
            <div class="row justify-content-center">
            <a class="btn bg-success text-white font-weight-bold     align-content-center text-center pl-4 pr-4" href="../index.php">Volver
           </a>
            <a class="btn bg-success text-white font-weight-bold     align-content-center text-center pl-4 pr-4 ml-3" href="principal.php?listarTodos">Listar en fichero
           </a>
           </div>
           <?php 

           Pie();   
        
    }           
    else
    {    
           
            Encabezado();
            echo "No se pudo conectar a la base de datos";
            ?>
            <div class="w-100 mb-2"></div>
            <div class="row justify-content-center">
             <a class="btn bg-success text-white font-weight-bold align-content-center text-center pl-4 pr-4" href="../index.php">Volver
        </a>
        </div>
        <?php 
        Pie();
    }

  




}

function listarTodos($id_usu,$nombre,$resultado,$intentos,$cuenta_resu)
{

     if($conexion=mysqli_connect("localhost","root",""))
     {       
            mysqli_select_db($conexion,"QueMareoSudoku");
            $consulta=mysqli_query($conexion,"Select id_usuario 'id_usuario',nombre 'nombre',ganapierde 'resultado',
            sum(intentos)'intentos',count(ganapierde)'cuenta_resu' from  
            Usuarios u join Partidas p on id_usuario=idUsu
            group by 1,2,3" );
           $i=0;        
               while($registro = mysqli_fetch_assoc($consulta))
               {     
                   $id_usu[$i]=$registro['id_usuario'];
                   $nombre[$i]=$registro['nombre'];
                   $resultado[$i]=$registro['resultado'];
                   $intentos[$i]=$registro['intentos'];
                   $cuenta_resu[$i]=$registro['cuenta_resu'];
                   $i++; 
               } 
     }          
          
         
           
    
        $f1=fopen("ficheroTodos.txt","a+");
        for($i=0;$i<count($id_usu);$i++)
        {    
            fwrite($f1,'id_usuario: '.$id_usu[$i].' nombre: '.$nombre[$i].' resultado: '.$resultado[$i].' intentos: '.$intentos[$i].' cuenta resultados: '.$cuenta_resu[$i]."\r\n");
        }    
            
        fclose($f1);
        header('location:../formularios/consultar.php');
    
}


 /*if($listar==1)
           {
              for($i=0;$i<count($id_usu);$i++)
              {
              listarTodos($id_usu,$nombre,$resultado,$intentos,$cuenta_resu);
              }
           } */



function ordenados_por_jugadas_ganadas()
{
     
     if($conexion=mysqli_connect("localhost","root",""))
     {       
            mysqli_select_db($conexion,"QueMareoSudoku");
            $consulta=mysqli_query($conexion,"Select id_usuario 'id_usuario',nombre 'nombre',ganapierde 'resultado',
            sum(intentos)'intentos',count(ganapierde)'cuenta_resu' 
            from  
            Usuarios u join Partidas p on id_usuario=idUsu
            where ganapierde like 'gana'
            group by 1,2,3
            order by count(ganapierde) asc" );
           $i=0;        
               while($registro = mysqli_fetch_assoc($consulta))
               {     
                   $id_usu[$i]=$registro['id_usuario'];
                   $nombre[$i]=$registro['nombre'];
                   $resultado[$i]=$registro['resultado'];
                   $intentos[$i]=$registro['intentos'];
                   $cuenta_resu[$i]=$registro['cuenta_resu'];
                   $i++; 
               } 
          
           
                  
                
           Encabezado();
           ?>
           <table class="table-bordered table-striped">
           <tr>
           <th class="p-2">Id usuario</th><th>Nombre</th>
           <th>Resultado</th><th>Intentos</th><th>Cuenta resultados</th>
           </tr>
           <?php  
           for($i=0;$i<count($id_usu);$i++)
           {
             echo "<tr><td align='center'>$id_usu[$i]</td><td align='center'>$nombre[$i]</td><td align='center'>$resultado[$i]</td><td align='center'>$intentos[$i]</td><td align='center'>$cuenta_resu[$i]</td></tr>";
           } 
           echo "</tr>";
            ?>  
            </table>
             <div class="w-100 my-2"></div>
            <div class="row justify-content-center">
            <a class="btn bg-success text-white font-weight-bold     align-content-center text-center pl-4 pr-4" href="../index.php">Volver
           </a>
            <a class="btn bg-success text-white font-weight-bold     align-content-center text-center pl-4 pr-4 ml-3" href="principal.php?listarOrdenados">Listar en fichero
           </a>
           </div>
           <?php 

           Pie();   
        
    }           
    else
    {    
           
            Encabezado();
            echo "No se pudo conectar a la base de datos";
            ?>
            <div class="w-100 mb-2"></div>
            <div class="row justify-content-center">
             <a class="btn bg-success text-white font-weight-bold align-content-center text-center pl-4 pr-4" href="../index.php">Volver
        </a>
        </div>
        <?php 
        Pie();
    }

  




}


function listarTodosOrdenados($id_usu,$nombre,$resultado,$intentos,$cuenta_resu)
{

     if($conexion=mysqli_connect("localhost","root",""))
     {       
            mysqli_select_db($conexion,"QueMareoSudoku");
           $consulta=mysqli_query($conexion,"Select id_usuario 'id_usuario',nombre 'nombre',ganapierde 'resultado',
            sum(intentos)'intentos',count(ganapierde)'cuenta_resu' 
            from  
            Usuarios u join Partidas p on id_usuario=idUsu
            where ganapierde like 'gana'
            group by 1,2,3
            order by count(ganapierde) asc" );
           $i=0;        
               while($registro = mysqli_fetch_assoc($consulta))
               {     
                   $id_usu[$i]=$registro['id_usuario'];
                   $nombre[$i]=$registro['nombre'];
                   $resultado[$i]=$registro['resultado'];
                   $intentos[$i]=$registro['intentos'];
                   $cuenta_resu[$i]=$registro['cuenta_resu'];
                   $i++; 
               } 
     }          
          
         
           
    
        $f1=fopen("ficheroTodosOrdenados.txt","a+");
        for($i=0;$i<count($id_usu);$i++)
        {    
            fwrite($f1,'id_usuario: '.$id_usu[$i].' nombre: '.$nombre[$i].' resultado: '.$resultado[$i].' intentos: '.$intentos[$i].' cuenta resultados:'.$cuenta_resu[$i]."\r\n");
        }    
            
        fclose($f1);
        header('location:../formularios/consultar.php');
    
}



function consultarUsuario($nombre,$clave)
{

     if($conexion=mysqli_connect("localhost","root",""))
     {       
            mysqli_select_db($conexion,"QueMareoSudoku");
            $consulta=mysqli_query($conexion,"Select id_usuario 'id_usuario',nombre,ganapierde 'resultado',
            sum(intentos)'intentos',count(ganapierde)'cuenta_resu' from  
            Usuarios u join Partidas p on id_usuario=idUsu
            where nombre like '$nombre' and clave like '$clave'
            group by 1,2,3" );
       $num=mysqli_num_rows($consulta);
         if($num>0)
         {   
           $i=0;        
               while($registro = mysqli_fetch_assoc($consulta))
               {     
                   $id_usu[$i]=$registro['id_usuario'];
                   $nombre[$i]=$registro['nombre'];
                   $resultado[$i]=$registro['resultado'];
                   $intentos[$i]=$registro['intentos'];
                   $cuenta_resu[$i]=$registro['cuenta_resu'];
                   $i++; 
               } 
          
           
                  
                
           Encabezado();
           ?>
           <table class="table-bordered table-striped">
           <tr>
           <th class="p-2">Id usuario</th><th>Nombre</th>
           <th>Resultado</th><th>Intentos</th><th>Cuenta resultados</th>
           </tr>
           <?php  
           for($i=0;$i<count($id_usu);$i++)
           {
             echo "<tr><td align='center'>$id_usu[$i]</td><td align='center'>$nombre</td><td align='center'>$resultado[$i]</td><td align='center'>$intentos[$i]</td><td align='center'>$cuenta_resu[$i]</td></tr>";
           } 
           echo "</tr>";
            ?>  
            </table>
             <div class="w-100 my-2"></div>
            <div class="row justify-content-center">
            <a class="btn bg-success text-white font-weight-bold     align-content-center text-center pl-4 pr-4" href="../index.php">Volver
           </a>
         
           </div>
           <?php 
      
           Pie(); 
        }
        else {
                 Encabezado();
                 echo "El usuario no existe";
                 ?>
                   <div class="w-100 mb-2"></div>
                   <div class="row justify-content-center">
                   <a class="btn bg-success text-white font-weight-bold align-content-center text-center pl-4 pr-4" href="../index.php">Volver</a>
                 <?php 
                 Pie();  
             }     
        
    }           
    else
    {    
           
            Encabezado();
            echo "No se pudo conectar a la base de datos";
            ?>
            <div class="w-100 mb-2"></div>
            <div class="row justify-content-center">
             <a class="btn bg-success text-white font-weight-bold align-content-center text-center pl-4 pr-4" href="../index.php">Volver
        </a>
        </div>
        <?php 
        Pie();
    }



}