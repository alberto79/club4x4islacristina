<?php 
session_start();
include ("funciones.php");


if(isset($_POST['altaNombre']))
{
	

	$nombre=$_POST['altaNombre'];
	$clave=$_POST['altaClave'];
	usuario_alta($nombre,$clave);
}
	
if(isset($_POST['nombreloginusu']))
{
	$nombre=$_POST['nombreloginusu'];
	$clave=$_POST['claveloginusu'];
	iniciar_sesion($nombre,$clave);
	

}

if(isset($_POST['nombrebajaUsu']))
{
	$nombre=$_POST['nombrebajaUsu'];
	$clave=$_POST['claveBajaUsu'];

	baja_usuario($nombre,$clave);
	
}
if(isset($_POST['nombremodiUsu']))
{
	$nombre=$_POST['nombremodiUsu'];
	$clavevieja=$_POST['clavevieja'];
    $claveNueva=$_POST['clavenueva'];
	modifica_usuario($nombre,$clavevieja,$claveNueva);
	
}
if(isset($_GET['sudoku']))
{
	generarSudoku();
}


if(isset($_GET['Comprobar']))
{
   
  $n1=$_GET['num1']; 
  $n3=$_GET['num3']; 
  $n4=$_GET['num4']; 
  $n5=$_GET['num5']; 
  $n6=$_GET['num6']; 
  $num1=$_COOKIE['num1'];
  $num3=$_COOKIE['num3'];
  $num4=$_COOKIE['num4'];
  $num5=$_COOKIE['num5'];
  $num6=$_COOKIE['num6'];
  if($n1==$num1&&$n3==$num3&&$n4==$num4&&$n5==$num5&&$n6==$num6)
  { 
          
            header('location:../formularios/correcto.php');
            $correcto=1;
           

  }
  else
  	
  comprobarSudoku($n1,$n3,$n4,$n5,$n6);  
}   
if(isset($_GET['todos']))
{
	todos();
}
if(isset($_GET['listarTodos']))
{
	listarTodos();
}
if(isset($_GET['ordenados']))
{
	ordenados_por_jugadas_ganadas();
}
if(isset($_GET['listarOrdenados']))
{
	listarTodosOrdenados();
}
if(isset($_POST['nombreconsultaUsu']))
{
	$nombre=$_POST['nombreconsultaUsu'];
	$clave=$_POST['claveconsultaUsu'];
	consultarUsuario($nombre,$clave);
}


















?>

 
      

        
      















 

